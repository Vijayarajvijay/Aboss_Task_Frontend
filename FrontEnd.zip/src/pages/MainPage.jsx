import React, { useState, Suspense } from "react";
import { Button, Box, CircularProgress } from "@mui/material";

const StudentList = React.lazy(() => import("./StudentList"));

function MainPage() {
  const [remountKey, setRemountKey] = useState(0);

  return (
    <Box sx={{ textAlign: "center", mt: 4 }}>
      <Button
        variant="contained"
        color="secondary"
        onClick={() => setRemountKey((prev) => prev + 1)} // Triggers remount
        sx={{ mb: 2 }}
      >
        Remount StudentList
      </Button>

      {/* Lazy Loaded Component with Fallback */}
      <Suspense fallback={<CircularProgress />}>
        <StudentList key={remountKey} remountKey={remountKey} />
      </Suspense>
    </Box>
  );
}

export default MainPage;
